{-# LANGUAGE RecordWildCards #-}
module Parser where

import qualified Data.Map as Map
import qualified Text.Parsec.Token as Token
import qualified Text.Parsec.Expr as Expr
import qualified Parser.Lexer as Lexer
import Data.Map (Map)
import Text.Parsec
import Text.Parsec.String (Parser)
import Data.Functor.Identity (Identity)
import Parser.AST
import Parser.Error
import Utils
import Prelude hiding (lookup)
import Control.Exception (throw)
import Data.Maybe (listToMaybe)
import Data.Bifunctor (bimap)

type ParserEnv = Map.Map String AuraType

expr :: ParserEnv -> Parser AuraExpression
expr env = Expr.buildExpressionParser operations (expression env)
  where expression env = try integer
          <|> try float
          <|> try char
          <|> try string
          <|> try true
          <|> try false
          <|> try (list env)
          <|> try (map env)
          <|> try (tuple env)
          <|> try (object env)
          <|> try (closure env)
          <|> try (identifier env)
          <|> try (call env)

        -- simple literals
        integer = IntExpr <$> Lexer.integer
        float = FloatExpr <$> Lexer.float
        char = CharExpr <$> Lexer.charLiteral
        string = StringExpr <$> Lexer.stringLiteral
        true = Lexer.reserved "true" >> return (BooleanExpr True)
        false = Lexer.reserved "false" >> return (BooleanExpr False)

        -- collection literals
        list env = ListExpr <$> listLiteral (Lexer.commaSep $ expr env)
        map env = MapExpr <$> mapLiteral (Map.fromList <$> Lexer.commaSep (entry (expr env) (expr env) ":"))
        tuple env = TupleExpr <$> tupleLiteral (Lexer.commaSep $ expr env)
        object env = ObjectExpr <$> objectLiteral (Map.fromList <$> Lexer.commaSep (entry Lexer.identifier (expr env) ":"))

        closure env = do
          params <- Map.fromList <$> Lexer.parens (Lexer.commaSep (entry Lexer.identifier typeAnn ":"))
          Lexer.symbol ":"
          retType <- typeAnn
          Lexer.symbol "->"
          body <- expr $ params `Map.union` env

          return ClosureExpr {
            closureParams = params,
            closureRetType = retType,
            closureBody = body
          }
        
        identifier env = do
          name <- Lexer.identifier
          case name `Map.lookup` env of
            Just identType -> return IdentifierExpr {
              identName = name,
              identType 
            }
            Nothing -> throw $ UnknownIdent name
        
        call env = let params = Lexer.parens $ Lexer.commaSep $ expr env in do
          func <- expr env
          case func of
            ClosureExpr { closureRetType } -> do
              params <- params
              
              return CallExpr {
                callFunc = func,
                callArgs = params,
                callRetType = closureRetType
              }
            IdentifierExpr { identType, .. } -> case identType of
                ClosureType { params = paramsType, returnType } -> do
                  params <- params
                  -- if 
                  return CallExpr {
                    callFunc = func,
                    callArgs = params,
                    callRetType = identType
                  }

typeOf :: ParserEnv -> AuraExpression -> AuraType
typeOf env expr = case expr of
  IntExpr _ -> IntType
  FloatExpr _ -> FloatType
  CharExpr _ -> CharType
  StringExpr _ -> StringType
  BooleanExpr _ -> BooleanType
  ListExpr items -> ListType $ maybe VoidType (typeOf env) $ listToMaybe items
  MapExpr entries -> uncurry MapType 
    $ maybe (VoidType, VoidType) (bimap (typeOf env) (typeOf env)) 
    $ listToMaybe (Map.assocs entries)
  TupleExpr items -> TupleType $ map (typeOf env) items
  ObjectExpr fields -> ObjectType $ Map.map (typeOf env) fields
  ClosureExpr { closureParams, closureRetType, .. } -> ClosureType {
    params = map snd (Map.assocs closureParams),
    returnType = closureRetType
  }
  IdentifierExpr { identType, .. } -> identType
  CallExpr { callRetType, .. } -> callRetType
  BinaryOpExpr { binOp, lhs, rhs } -> case binOp of
    Assign -> typeOf env rhs
    Plus -> if typeOf env lhs == IntType && typeOf env rhs == IntType then IntType else FloatType
    Minus -> if typeOf env lhs == IntType && typeOf env rhs == IntType then IntType else FloatType
    -- PlusAssign -> 
    Times -> if typeOf env lhs == IntType && typeOf env rhs == IntType then IntType else FloatType
    Divide -> FloatType


typeAnn :: Parser AuraType
typeAnn = try intType
  <|> try floatType
  <|> try charType
  <|> try stringType
  <|> try booleanType
  <|> try voidType
  <|> try listType
  <|> try mapType
  <|> try closureType
  <|> try unionType

  where 
    intType = string "int" >> return IntType
    floatType = string "float" >> return FloatType
    charType = string "char" >> return CharType
    stringType = string "string" >> return StringType
    booleanType = string "boolean" >> return BooleanType
    voidType = string "void" >> return VoidType
    listType = ListType <$> listLiteral typeAnn
    mapType = uncurry MapType <$> mapLiteral (entry typeAnn typeAnn ":")
    tupleType = TupleType <$> tupleLiteral (Lexer.commaSep typeAnn)
    objectType = ObjectType <$> objectLiteral (Map.fromList <$> Lexer.commaSep (entry Lexer.identifier typeAnn ":"))
    closureType = do
      params <- Lexer.parens (Lexer.commaSep typeAnn)
      Lexer.symbol "->"
      retType <- typeAnn
      return ClosureType {
        params = params,
        returnType = retType
      }
    unionType = UnionType <$> typeAnn `sepBy` Lexer.symbol "|"

listLiteral :: Parser a -> Parser a
listLiteral = between (Lexer.symbol "#[") (Lexer.symbol "]")

mapLiteral :: Parser a -> Parser a
mapLiteral = between (Lexer.symbol "#{") (Lexer.symbol "}")

tupleLiteral :: Parser a -> Parser a
tupleLiteral = between (Lexer.symbol "#(") (Lexer.symbol ")")

objectLiteral :: Parser a -> Parser a
objectLiteral = between (Lexer.symbol "@{") (Lexer.symbol "}")

entry :: Parser a -> Parser b -> String -> Parser (a, b)
entry key value separator = do
  k <- key
  Lexer.symbol separator
  v <- value
  return (k, v)

binaryOp :: String -> BinaryOp -> Expr.Assoc -> Expr.Operator String () Identity AuraExpression
binaryOp op func = Expr.Infix (Lexer.operation op >> return (BinaryOpExpr func))

prefixOp :: String -> PrefixOp -> Expr.Operator String () Identity AuraExpression
prefixOp op func = Expr.Prefix (Lexer.operation op >> return (PrefixOpExpr func))

postfixOp :: String -> PostfixOp -> Expr.Operator String () Identity AuraExpression
postfixOp op func = Expr.Postfix (Lexer.operation op >> return (PostfixOpExpr func))

operations :: Expr.OperatorTable String () Identity AuraExpression
operations = [
  [binaryOp "**" Power Expr.AssocRight],
  [prefixOp "-" Negate]
  ]