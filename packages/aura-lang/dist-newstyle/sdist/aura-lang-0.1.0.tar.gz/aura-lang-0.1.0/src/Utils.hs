module Utils where

type Name = String