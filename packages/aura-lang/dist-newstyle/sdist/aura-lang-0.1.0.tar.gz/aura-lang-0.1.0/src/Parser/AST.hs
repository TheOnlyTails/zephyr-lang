{-# LANGUAGE RecordWildCards, TemplateHaskell, DataKinds, TypeFamilies #-}
module Parser.AST where

import Data.Text ( unpack, toLower, pack )
import Data.List
import Data.Maybe (fromMaybe)
import Utils (Name)
import Data.Map (Map)
import qualified Data.Map as Map
import Generics.Deriving
import Generics.Deriving.TH

data BinaryOp = 
  Assign |
  Plus |
  PlusAssign |
  Minus |
  MinusAssign |
  Times |
  TimesAssign |
  Divide |
  DivideAssign |
  Modulus |
  ModulusAssign |
  Power |
  PowerAssign |
  Equals |
  NotEquals |
  LessThan |
  LessThanEquals |
  GreaterThan |
  GreaterThanEquals |
  And |
  Or |
  In |
  NotIn
  deriving (Show, Eq, Ord)

data PrefixOp =
  Negate |
  Not
  deriving (Show, Eq, Ord)

data PostfixOp =
  Increment |
  Decrement
  deriving (Show, Eq, Ord)

data AuraType =
  IntType |
  FloatType |
  CharType |
  StringType |
  BooleanType |
  VoidType |
  ListType AuraType |
  MapType AuraType AuraType |
  TupleType [AuraType] |
  ObjectType (Map String AuraType) |
  ClosureType {
    params :: [AuraType],
    returnType :: AuraType
  } |
  UnionType [AuraType]
  deriving (Eq, Ord)

$(deriveAll0 ''AuraType)

data AuraValue = 
  IntValue Integer |
  FloatValue Double |
  CharValue Char |
  StringValue String |
  BooleanValue Bool |
  ListValue [AuraValue] |
  MapValue (Map AuraValue AuraValue) |
  TupleValue [AuraValue] |
  ObjectValue (Map Name AuraValue) |
  VoidValue |
  ClosureValue (Map Name AuraType) AuraExpression AuraType 

data AuraExpression = 
  IntExpr Integer |
  FloatExpr Double |
  CharExpr Char |
  StringExpr String |
  BooleanExpr Bool |
  ListExpr [AuraExpression] |
  MapExpr (Map AuraExpression AuraExpression) |
  TupleExpr [AuraExpression] |
  ObjectExpr (Map String AuraExpression) |
  ClosureExpr {
    closureParams :: Map String AuraType,
    closureRetType :: AuraType,
    closureBody :: AuraExpression
  } |
  IdentifierExpr {
    identName :: Name,
    identType :: AuraType
  } |
  CallExpr {
    callFunc :: AuraExpression,
    callArgs :: [AuraExpression],
    callRetType :: AuraType
  } |
  BinaryOpExpr {
    binOp :: BinaryOp,
    lhs :: AuraExpression,
    rhs :: AuraExpression
  } |
  PrefixOpExpr PrefixOp AuraExpression |
  PostfixOpExpr PostfixOp AuraExpression |
  LetExpr {
    letName :: Name,
    letMutable :: Bool,
    letValue :: AuraExpression,
    letType :: AuraType
  } |
  IfExpr {
    ifCond :: AuraExpression,
    ifThen :: AuraExpression,
    ifElse :: Maybe AuraExpression
  } |
  WhileExpr {
    whileCond :: AuraExpression,
    whileBody :: AuraExpression
  } |
  ForExpr {
    forVariableName :: Name, 
    forIterable :: AuraExpression,
    forBody :: AuraExpression
  } |
  -- for idents - if doesn't exist, import everything
  -- if it does, each ident may or may not have an alias
  ImportExpr String (Maybe (Map Name (Maybe Name))) |
  CastExpr AuraExpression AuraType |
  TypeCheckExpr AuraExpression AuraType |
  CodeBlockExpr [AuraExpression]
  deriving (Eq, Ord)

$(deriveAll0 ''AuraExpression);

instance Show AuraExpression where
  show expr = case expr of
    IntExpr val -> show val
    FloatExpr val -> show val
    CharExpr val -> "'" ++ show val ++ "'"
    StringExpr val -> "\"" ++ val ++ "\""
    BooleanExpr val -> unpack . toLower . pack $ show val
    ListExpr items -> "#[" ++ intercalate ", " (map show items) ++ "]"
    MapExpr entries -> "#{" ++ showEntries entries ++ "}"
    TupleExpr items -> "#(" ++ intercalate ", " (map show items) ++ ")"
    ObjectExpr fields -> "@{" ++ showEntries fields ++ "}"
    ClosureExpr { closureParams, closureRetType, closureBody } -> 
      "(" ++ showEntries closureParams ++ "): " ++ show closureRetType ++ " -> " ++ show closureBody
    IdentifierExpr { identName, .. } -> identName
    CallExpr { callFunc, callArgs } -> (case callFunc of 
      IdentifierExpr {..} -> show callFunc
      _ -> "(" ++ show callFunc ++ ")"
      ) ++ "(" ++ intercalate ", " (map show callArgs) ++ ")"
    BinaryOpExpr { binOp, lhs, rhs } -> show lhs ++ " " ++ show binOp ++ " " ++ show rhs
    PrefixOpExpr op expr -> show op ++ show expr
    PostfixOpExpr op expr -> show expr ++ show op
    LetExpr { letName, letMutable, letType, letValue } -> 
      "let " ++ (if letMutable then "mut " else "") ++ letName ++
      ": " ++ show letType ++ " = " ++ show letValue
    IfExpr { ifCond, ifThen, ifElse } -> 
      "if (" ++ show ifCond ++ ") " ++ show ifThen ++
      "\nelse " ++ show ifElse
    WhileExpr { whileCond, whileBody } -> "while (" ++ show whileCond ++ ") " ++ show whileBody
    ForExpr { forVariableName, forIterable, forBody } -> 
      "for (" ++ forVariableName ++ " in " ++ show forIterable ++ ") " ++ show forBody
    ImportExpr path idents -> "import \"" ++ path ++ "\"" ++ 
      maybe "" (\idents -> " with (" ++ 
      (intercalate ", " . map (\(ident, alias) -> ident ++ maybe "" (" as "++) alias)) (Map.assocs idents) 
      ++ ")") idents
    CastExpr expr to -> show expr ++ " as " ++ show to
    TypeCheckExpr expr is -> show expr ++ " is " ++ show is
    CodeBlockExpr body -> "{\n" ++ (intercalate "\n" . map (("\t"++) . show) $ body) ++ "\n}" 

showEntries :: (Show k, Show v) => Map k v -> String
showEntries entries = intercalate ", " 
  (map (\(k, v) -> show k ++ ": " ++ show v) (Map.assocs entries))

instance Show AuraType where
  show typeDef = case typeDef of
    IntType -> "int"
    FloatType -> "float"
    CharType -> "char"
    StringType -> "string"
    BooleanType -> "boolean"
    VoidType -> "void"
    ListType elem -> "#[" ++ show elem ++ "]"
    MapType key value -> "#{" ++ show key ++ ": " ++ show value ++ "}"
    TupleType items -> "#(" ++ (intercalate ", " . map show) items ++ ")"
    ObjectType fields -> "#{" ++ showEntries fields ++ "}"
    ClosureType { params, returnType } -> 
      "(" ++ (intercalate ", " . map show) params ++ ") -> " ++ show returnType
    UnionType types -> intercalate " | " . map show $ types

assignableTo :: AuraType -> AuraType -> Bool
assignableTo from to = (from == to) || (case (from, to) of 
  (_, VoidType) -> False 
  (IntType, FloatType) -> True
  (FloatType, IntType) -> True
  (StringType, ListType CharType) -> True
  (ListType CharType, StringType) -> True
  (UnionType aTypes, UnionType bTypes) -> all (\a -> any (\b -> a `assignableTo` b) bTypes) aTypes
  (_, UnionType types) -> from `elem` types
  (MapType mapKey mapValue, ObjectType fields) -> mapKey `assignableTo` StringType && all (mapValue `assignableTo`) fields
  (ObjectType fields, MapType mapKey mapValue) -> mapKey `assignableTo` StringType && all (`assignableTo` mapValue) fields
  (TupleType items, ListType elemType) -> all (`assignableTo` elemType) items
  (ListType elemType, TupleType items) -> all (elemType `assignableTo`) items
  (ListType from, ListType to) -> from `assignableTo` to
  (MapType fromK fromV, MapType toK toV) -> fromK `assignableTo` toK && fromV `assignableTo` toV
  (TupleType fromItems, TupleType toItems) -> all (uncurry assignableTo) (zip fromItems toItems)
  (ObjectType fromFields, ObjectType toFields) -> all 
    (\(k, v) -> v `assignableTo` fromMaybe VoidType (k `Map.lookup` toFields)) 
    (Map.assocs fromFields)
  )
