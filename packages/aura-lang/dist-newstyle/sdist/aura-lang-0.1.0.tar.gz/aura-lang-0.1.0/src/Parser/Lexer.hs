module Parser.Lexer where

import qualified Text.Parsec.Token as Token
import Text.Parsec.String (Parser)
import Text.Parsec
import Parser.AST (AuraExpression)
import Text.Parsec.Token (GenTokenParser(reserved))
import Data.Map

definition :: Token.LanguageDef ()
definition = Token.LanguageDef {
  Token.commentLine = "//",
  Token.commentStart = "/*",
  Token.commentEnd = "*/",
  Token.nestedComments = False,
  Token.identStart = letter <|> char '_',
  Token.identLetter = alphaNum <|> char '_',
  Token.opStart = Token.opLetter definition,
  Token.opLetter = oneOf "+-*%=!<>&|inas",
  Token.reservedNames = [
    "let",
    "mut",
    "if",
    "while",
    "for",
    "import",
    "as",
    "is",
    "true",
    "false"
  ],
  Token.reservedOpNames = [
    "=", 
    "+", "+=", 
    "-", "-=", 
    "*", "*=",
    "/", "/=",
    "%", "%=",
    "**", "**=",
    "==", "!=",
    "<", "<=",
    ">", ">=",
    "&&", "||",
    "in", "!in",
    "as", "is"
  ],
  Token.caseSensitive = True
}

lexer :: Token.TokenParser ()
lexer = Token.makeTokenParser definition

identifier :: Parser String
identifier = Token.identifier lexer

parens :: Parser a -> Parser a
parens = Token.parens lexer

brackets :: Parser a -> Parser a
brackets = Token.brackets lexer

braces :: Parser a -> Parser a
braces = Token.braces lexer

angles :: Parser a -> Parser a
angles = Token.angles lexer

symbol :: String -> Parser String
symbol = Token.symbol lexer

commaSep :: Parser a -> Parser [a]
commaSep = Token.commaSep lexer

operation :: String -> Parser ()
operation = Token.reservedOp lexer

integer :: Parser Integer
integer = Token.natural lexer

float :: Parser Double
float = Token.float lexer

charLiteral :: Parser Char
charLiteral = Token.charLiteral lexer

stringLiteral :: Parser String
stringLiteral = Token.stringLiteral lexer

reserved :: String -> Parser ()
reserved = Token.reserved lexer
