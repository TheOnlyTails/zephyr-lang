module Parser.Error where 

import Parser.AST (AuraType)
import Data.Data ( Typeable )
import GHC.Exception (Exception)
import Utils (Name)

data ParserError = 
  CannotAssign AuraType AuraType |
  UnknownIdent Name
  deriving (Typeable)

instance Show ParserError where
  show err = case err of
    CannotAssign from to -> "A value of type `" ++ show from ++ "` to a value of type `" ++ show to ++ "`."
    UnknownIdent name -> "Could not find a value named '" ++ name ++ "' in scope."


instance Exception ParserError