module Main where

main :: IO ()
main = do
  putStrLn "Hello, Haskell!"
